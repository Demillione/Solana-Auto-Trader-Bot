# Solana Auto-Trader Final

Flat-structured version for direct Render ZIP deployment. This includes:

- AI-powered narrative scan (Grok)
- Honeypot protection
- Auto-buy and auto-sell
- Google Sheets logging
- Telegram alerts

Upload this ZIP directly to Render and add your environment variables manually.